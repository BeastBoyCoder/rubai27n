import tkinter as tk
from tkinter import ttk
import psutil
import platform
import win32api
import subprocess
import winreg

# -----------------------------
# Helper functions to query WMI / Registry
# -----------------------------

def _wmic(cmd: str) -> str:
    """Run a WMIC command and return the first non‑header line stripped."""
    try:
        raw = subprocess.check_output(["wmic", *cmd.split()]).decode(errors="ignore").splitlines()
        return next((l.strip() for l in raw if l.strip() and l.split()[0].lower() != cmd.split()[-1].lower()), "Unknown")
    except Exception:
        return "Unknown"


def get_serial_number() -> str:
    return _wmic("bios get serialnumber")


def get_model_number() -> str:
    return _wmic("computersystem get model")


def get_form_factor() -> str:
    pcsystemtype = _wmic("computersystem get pcSystemType")
    # According to MS docs: 1 = Desktop, 2 = Mobile / Laptop, others various
    return "Laptop" if pcsystemtype == "2" else "Desktop"


def get_installed_apps() -> list[str]:
    """Return a sorted list of installed application names from both HKLM & HKCU"""
    apps = set()
    registry_paths = [
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_CURRENT_USER, r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"),
        (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall"),
    ]
    for hive, path in registry_paths:
        try:
            with winreg.OpenKey(hive, path) as uninstall_key:
                for i in range(0, winreg.QueryInfoKey(uninstall_key)[0]):
                    try:
                        subkey_name = winreg.EnumKey(uninstall_key, i)
                        with winreg.OpenKey(uninstall_key, subkey_name) as subkey:
                            name, _ = winreg.QueryValueEx(subkey, "DisplayName")
                            if name:
                                apps.add(name)
                    except FileNotFoundError:
                        continue
                    except OSError:
                        continue
        except FileNotFoundError:
            continue
    return sorted(apps, key=str.casefold)

# -----------------------------
# Core system‑info aggregation
# -----------------------------

def get_windows_version():
    version_info = win32api.GetVersionEx()
    major_version = version_info[0]
    build_number = version_info[2]
    if major_version == 10 and build_number >= 22000:
        return "Windows 11"
    elif major_version == 10:
        return "Windows 10"
    else:
        return f"Unknown Windows Version {major_version}"


def get_system_info():
    uname_info = platform.uname()
    cpu_info = psutil.cpu_freq()
    memory_info = psutil.virtual_memory()
    swap_info = psutil.swap_memory()
    disk_info = psutil.disk_usage('/')

    info = {
        "Operating System": get_windows_version(),
        "Architecture": platform.architecture()[0],
        "Serial Number": get_serial_number(),
        "Model Number": get_model_number(),
        "Form Factor": get_form_factor(),
        "System": uname_info.system,
        "Node Name": uname_info.node,
        "Release": uname_info.release,
        "Version": uname_info.version,
        "Machine": uname_info.machine,
        "Processor": uname_info.processor,
        "CPU Frequency": f"{cpu_info.current:.0f} MHz" if cpu_info else "Unknown",
        "CPU Usage": f"{psutil.cpu_percent()}%",
        "Total Memory": f"{memory_info.total / (1024 ** 3):.2f} GB",
        "Used Memory": f"{memory_info.used / (1024 ** 3):.2f} GB",
        "Free Memory": f"{memory_info.available / (1024 ** 3):.2f} GB",
        "Memory Usage": f"{memory_info.percent}%",
        "Total Swap": f"{swap_info.total / (1024 ** 3):.2f} GB",
        "Used Swap": f"{swap_info.used / (1024 ** 3):.2f} GB",
        "Free Swap": f"{swap_info.free / (1024 ** 3):.2f} GB",
        "Swap Usage": f"{swap_info.percent}%",
        "Total Disk": f"{disk_info.total / (1024 ** 3):.2f} GB",
        "Used Disk": f"{disk_info.used / (1024 ** 3):.2f} GB",
        "Free Disk": f"{disk_info.free / (1024 ** 3):.2f} GB",
        "Disk Usage": f"{disk_info.percent}%",
    }

    return info

# -----------------------------
# UI Setup with ttk.Notebook
# -----------------------------

def build_ui():
    root = tk.Tk()
    root.title("System Information Collector")
    root.geometry("700x600")

    notebook = ttk.Notebook(root)
    notebook.pack(fill="both", expand=True)

    # Tab 1: System Info
    frame_info = ttk.Frame(notebook)
    notebook.add(frame_info, text="System Info")

    labels = {}
    for idx, key in enumerate(get_system_info().keys()):
        label = ttk.Label(frame_info, text=f"{key}: ", font=("Helvetica", 10))
        label.grid(row=idx, column=0, sticky="w", padx=10, pady=2)
        labels[key] = label

    # Tab 2: Installed Applications
    frame_apps = ttk.Frame(notebook)
    notebook.add(frame_apps, text="Installed Applications")

    app_listbox = tk.Listbox(frame_apps, font=("Helvetica", 10))
    app_listbox.pack(fill="both", expand=True, padx=10, pady=10)

    # Populate apps once at startup (they rarely change)
    for app_name in get_installed_apps():
        app_listbox.insert(tk.END, app_name)

    # Update function for dynamic metrics in Tab 1
    def update_info():
        info = get_system_info()
        for key, value in info.items():
            labels[key].config(text=f"{key}: {value}")
        root.after(1000, update_info)  # refresh every second

    update_info()
    return root


if __name__ == "__main__":
    build_ui().mainloop()
