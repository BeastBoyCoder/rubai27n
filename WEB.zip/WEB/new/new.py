a = ["b", "boy", "cat"]
for b in a:
    print(b)
print("the above words is my list and tell me which of them is your favorite")
c = input()
if c in a:
    print("yep understood")
else:
    print("nope thats not in my list")
