#!/usr/bin/env python
"""
belarc_clone.py  –  Generate a Belarc‑style HTML inventory on Windows
--------------------------------------------------------------------
Usage:
    python belarc_clone.py            # writes report.html next to the script
"""

import os, sys, json, socket, uuid, platform, subprocess, datetime, ctypes
import psutil, winreg, wmi
from pathlib import Path
from jinja2 import Template

C = wmi.WMI()

# ----------------------------------------------------------------------
# Helper utilities
# ----------------------------------------------------------------------
def run(cmd: str) -> str:
    """Run shell command and return stdout (ignore errors)."""
    try:
        return subprocess.check_output(cmd, shell=True, text=True, stderr=subprocess.DEVNULL)
    except subprocess.CalledProcessError:
        return ""


def from_registry(root, path, name, default=""):
    try:
        with winreg.OpenKey(root, path) as k:
            return winreg.QueryValueEx(k, name)[0]
    except FileNotFoundError:
        return default


def unix_to_dt(timestamp: int) -> str:
    return datetime.datetime.fromtimestamp(timestamp).strftime("%d-%b-%Y %H:%M:%S")


# ----------------------------------------------------------------------
# Collectors
# ----------------------------------------------------------------------
def os_info():
    win_os = C.Win32_OperatingSystem()[0]
    edition = win_os.Caption
    ver = win_os.Version
    build = win_os.BuildNumber
    arch = win_os.OSArchitecture
    install_ts = from_registry(winreg.HKEY_LOCAL_MACHINE, r"SYSTEM\Setup", "InstallDate", 0)
    language = from_registry(winreg.HKEY_LOCAL_MACHINE,
                             r"SYSTEM\CurrentControlSet\Control\Nls\Language", "InstallLanguage", "")
    language = {"0409": "English (United States)"}.get(language, language)
    # Boot mode
    boot_mode = "UEFI" if "path                    \EFI" in run("bcdedit") else "Legacy BIOS"
    # Secure Boot
    sb = run("powershell -command \"Confirm-SecureBootUEFI\"").strip()
    secure_boot = {"True": "Enabled", "False": "Disabled"}.get(sb, "Unknown/Unsupported")

    return {
        "caption": f"{edition} {arch}",
        "version": ver,
        "build": build,
        "install_date": unix_to_dt(int(install_ts)) if install_ts else "Unknown",
        "language": language,
        "boot_mode": boot_mode,
        "secure_boot": secure_boot,
    }


def cpu_info():
    cpu = C.Win32_Processor()[0]
    return {
        "name": cpu.Name.strip(),
        "cores": psutil.cpu_count(logical=False),
        "threads": psutil.cpu_count(logical=True),
        "max_clock_mhz": cpu.MaxClockSpeed,
        "l3_cache": f"{cpu.L3CacheSize} KB" if cpu.L3CacheSize else "—",
    }


def motherboard_info():
    board = C.Win32_BaseBoard()[0]
    bios = C.Win32_BIOS()[0]
    return {
        "manufacturer": board.Manufacturer,
        "product": board.Product,
        "serial": board.SerialNumber.strip(),
        "bios_vendor": bios.Manufacturer,
        "bios_version": bios.SMBIOSBIOSVersion,
        "bios_date": bios.ReleaseDate[:8]  # yyyymmddHHMMSS…
    }


def memory_info():
    total = round(psutil.virtual_memory().total / 2**30, 2)
    dimms = [
        #f"{m.Capacity//2**30} GB {m.Manufacturer} {m.Speed} MHz"
        f"{int(m.Capacity)//2**30} GB {m.Manufacturer} {m.Speed} MHz"
        for m in C.Win32_PhysicalMemory()
    ]
    return {"total_gb": total, "modules": dimms}


def disk_info():
    disks = []
    for disk in C.Win32_DiskDrive():
        size = round(int(disk.Size) / 2**30, 1)
        health = disk.Status
        disks.append(f"{disk.Model} — {size} GB ({health})")
    return disks


def network_info():
    import socket, psutil, wmi
    C = wmi.WMI()

    adapters = []
    for nic in C.Win32_NetworkAdapter():
        try:
            if nic.NetEnabled and getattr(nic, "ConfigManagerErrorCode", 0) == 0:
                mac = nic.MACAddress or "—"
                speed = (
                    f"{int(nic.Speed)//1_000_000} Mbps" if nic.Speed else "—"
                )
                adapters.append(f"{nic.Name}  {mac}  {speed}")
        except Exception:
            # Skip any NIC that throws odd errors
            continue

    # Collect every IPv4 on the box
    ips = [
        addr.address
        for addrs in psutil.net_if_addrs().values()
        for addr in addrs
        if addr.family == socket.AF_INET
    ]

    return {
        "hostname": socket.gethostname(),
        "ips": ips,
        "adapters": adapters,
    }



def installed_software():
    paths = [
        r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall",
        r"SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall",
    ]
    progs = []
    for root in (winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER):
        for path in paths:
            try:
                with winreg.OpenKey(root, path) as key:
                    for i in range(winreg.QueryInfoKey(key)[0]):
                        sub = winreg.EnumKey(key, i)
                        with winreg.OpenKey(key, sub) as subkey:
                            name = from_registry(None, None, None)  # placeholder
            except FileNotFoundError:
                continue
    # alternative (faster) via WMI:
    for p in C.Win32_Product():
        progs.append(f"{p.Name}  {p.Version}")
    return sorted(set(progs))


def windows_updates():
    return [f"{q.HotFixID}  {q.Description or ''}" for q in C.Win32_QuickFixEngineering()]


def av_status():
    avs = C.__getattr__("root\\SecurityCenter2").AntiVirusProduct()
    if not avs:
        return "Unknown / Not reported"
    return ", ".join(f"{a.displayName} ({a.productState:x})" for a in avs)


def users_and_groups():
    users = [u.Name for u in C.Win32_UserAccount(LocalAccount=True)]
    groups = [g.Name for g in C.Win32_Group() if "Builtin" not in g.Name]
    return {"users": users, "groups": groups}


# ----------------------------------------------------------------------
# HTML Report
# ----------------------------------------------------------------------
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>System Inventory Report – {{ host }}</title>
<style>
body{font-family:Segoe UI,Arial;margin:0;padding:1rem;background:#f8f8f8;color:#212121}
h2{margin-top:1.5rem}
section{background:#fff;padding:1rem;border-radius:8px;box-shadow:0 2px 4px rgba(0,0,0,.08);margin-bottom:1rem}
table{width:100%;border-collapse:collapse}
td{padding:.4rem .6rem;vertical-align:top}
td:first-child{font-weight:600;width:25%}
tr:nth-child(odd){background:#fafafa}
code{background:#eee;padding:2px 4px;border-radius:4px}
</style>
</head><body>
<h1>System Inventory – {{ host }}</h1>

{% macro kv(section) -%}
<section><h2>{{ section.name }}</h2><table>
{% for k,v in section.items %}
<tr><td>{{ k }}</td><td>{{ v }}</td></tr>
{% endfor %}</table></section>
{%- endmacro %}

{{ kv(system) }}
{{ kv(cpu) }}
{{ kv(mobo) }}

<section><h2>Memory</h2>
<p><b>Total:</b> {{ memory.total_gb }} GB</p>
<ul>{% for m in memory.modules %}<li>{{ m }}</li>{% endfor %}</ul>
</section>

<section><h2>Storage</h2>
<ul>{% for d in disks %}<li>{{ d }}</li>{% endfor %}</ul>
</section>

{{ kv(net) }}

<section><h2>Installed Software ({{ software|length }})</h2>
<ul>{% for s in software %}<li>{{ s }}</li>{% endfor %}</ul>
</section>

<section><h2>Hotfixes / Updates ({{ updates|length }})</h2>
<ul>{% for u in updates %}<li>{{ u }}</li>{% endfor %}</ul>
</section>

{{ kv(sec) }}
{{ kv(accounts) }}

<footer style="margin-top:2rem;font-size:.8rem;color:#555">
Generated {{ now }} by belarc_clone.py
</footer>
</body></html>
"""


def save_html(data, outfile="report.html"):
    tmpl = Template(HTML_TEMPLATE)
    html = tmpl.render(**data)
    Path(outfile).write_text(html, encoding="utf‑8")
    print(f"Report written to {outfile}")
    os.startfile(outfile)  # open in default browser (Windows only)


# ----------------------------------------------------------------------
def main():
    data = {
        "host": socket.gethostname(),
        "now": datetime.datetime.now().strftime("%d‑%b‑%Y %H:%M"),
        "system": {"name": "Operating System", "items": os_info()},
        "cpu": {"name": "Processor", "items": cpu_info()},
        "mobo": {"name": "Main Circuit Board", "items": motherboard_info()},
        "memory": memory_info(),
        "disks": disk_info(),
        "net": {"name": "Network", "items": network_info()},
        "software": installed_software(),
        "updates": windows_updates(),
        "sec": {"name": "Security", "items": {"Antivirus": av_status()}},
        "accounts": {"name": "Local Users & Groups", "items": users_and_groups()},
    }
    save_html(data)


if __name__ == "__main__":
    if os.name != "nt":
        sys.exit("This script is Windows-only.")
    main()
