let currentResult = "";
let operators = ["+", "-", "*", "/"];

function insertNumber(number) {
  currentResult += number;
  document.getElementById("result").value = currentResult;
}

function insertOperator(operator) {
  if (operators.includes(currentResult.slice(-1))) {
    currentResult = currentResult.slice(0, -1);
  }
  currentResult += operator;
  document.getElementById("result").value = currentResult;
}

function insertDecimal() {
  if (!currentResult.includes(".")) {
    currentResult += ".";
  }
  document.getElementById("result").value = currentResult;
}

function backspace() {
  currentResult = currentResult.slice(0, -1);
  document.getElementById("result").value = currentResult;
}

function clearResult() {
  currentResult = "";
  document.getElementById("result").value = "";
}

function calculateResult() {
  try {
    let result = eval(currentResult);
    document.getElementById("result").value = result;
    currentResult = result;
  } catch (error) {
    document.getElementById("result").value = "Error";
  }
}