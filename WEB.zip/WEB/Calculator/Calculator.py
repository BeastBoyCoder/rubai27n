def Q():
    print("Thanks for visting")  
num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))
print ("Addition = ",num1 + num2)
print ("Subtraction = ",num1 - num2)
print ("multiplication = ",num1 * num2)
print ("Devision = ",num1 / num2)
num = input ("if you want to calculate more than write R or if you want exit than write Q ")
if num == ("R") or ("r"):
    print("")
else:
    Q()